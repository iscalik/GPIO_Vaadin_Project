#! /bin/bash

function printHelp() {
	echo "Usage:" $0 "[OPTION_1][OPTION_2]... [OPTION_N]"
        echo
        echo "Possible options:"
       	echo -e "--help\t\tThis help."
	echo -e "--verbose\tWrite information to standard output."
        echo -e "--nosec\t\tIgnore the seconds (always set them to 0)."
        echo
	echo "Binary clock bash script v1.0 (2012.11.06) by IQ Jar"
	echo "http://iqjar.com"
	echo
	echo "Uses the gpio utility written by Gordon Henderson. For more info visit:"
        echo "https://projects.drogon.net/raspberry-pi/wiringpi/the-gpio-utility/"
        echo
}

function parseArguments() {
	if [ "$#" -ge 1 ]; then
		for i in "$@"; do
			if [ $i == "--help" ]; then
				printHelp
				exit 0
			elif [ $i == "--verbose" ]; then
				opt_verbose=true
			elif [ $i == "--nosec" ]; then
				opt_noseconds=true
			else
				printHelp
				exit 0
			fi
		done
	fi
}

function initGPIOPins() {
	#Initialize all the GPIO ports to output mode
	for i in `seq 0 16`; do gpio mode $i out; done
}

function fillBufferFromTime() {
	#Hours
	for i in `seq 0 4`; do curBinBuf[$i]=$((($1 & (1 << (4 - i))) >> (4 - i))); done

	#Minutes
        for i in `seq 5 10`; do curBinBuf[$i]=$((($2 & (1 << (10 - i))) >> (10 - i))); done

	#Seconds
	if [ $opt_noseconds == false ]; then
	        for i in `seq 11 16`; do curBinBuf[$i]=$((($3 & (1 << (16 - i))) >> (16-i))); done
	else
		for i in `seq 11 16`; do binbuf[$i]=0 ; done
	fi
}

function outputToStdOut() {
	if [ $opt_verbose == true ]; then
		echo -n "[$1:$2:$3.$4]"

		for i in `seq 0 4`; do echo -n ${curBinBuf[$i]}; done
		echo -n " "
		for i in `seq 5 10`; do echo -n ${curBinBuf[$i]}; done
        	echo -n " "
		for i in `seq 11 16`; do echo -n ${curBinBuf[$i]}; done
        	echo -n " "

		for i in `seq 0 16`; do
	                if ((${curBinBuf[$i]} != ${prevBinBuf[$i]})); then
                                echo -n "$i=${curBinBuf[$i]} "
                	fi
        	done

		echo
	fi
}

function ouputToGPIO() {
        for i in `seq 0 16`; do
		if ((${curBinBuf[$i]} != ${prevBinBuf[$i]})); then
			gpio write $i ${curBinBuf[$i]}
		fi
	done
}


#main starts here

#Binary buffers consisting of 17 elements
#(5 for hours, 6 for minutes, 6 for seconds)
declare -a prevBinBuf=( 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 ) #use 2 here so that the first time the loop runs, it detects that every value has changed
declare -a curBinBuf=( 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 )

#Options
opt_noseconds=false #Ignore the seconds, always set them to 0
opt_verbose=false #Write info to standard ouput

#Initializations
parseArguments "$@"
initGPIOPins

#Main loop
while true; do
	t=`date +%-H:%-M:%-S:%4N`
	read hr min sec nanosec <<< ${t//[-:]/ }

       	fillBufferFromTime "$hr" "$min" "$sec"
        outputToStdOut "$hr" "$min" "$sec" "$nanosec"
       	ouputToGPIO

	prevBinBuf=("${curBinBuf[@]}")

	sleep $(printf "0.%09d" $((1000000000-`date +%-N`)))
done

#! /bin/bash

#Helper functions
function printHelp() {
	echo "Usage:" $0 "[OPTION_1][OPTION_2]... [OPTION_N]"
        echo
        echo "Possible options:"
       	echo -e "--help\t\tThis help."
	echo -e "--long\t\tDouble animation time."
	echo -e "--short\t\tHalf animation time."
	echo -e "--verbose\tWrite information to standard output."
        echo -e "-a NAME\t\tRuns the specified animation."
	echo -e "-t SECONDS\tNumber of seconds to run the animation for."
	echo -e "\t\tIf not specified, the animation is run forever."
        echo
	echo "Lishtshow bash script v1.0 (2012.11.13) written by IQ Jar"
	echo "http://iqjar.com"
	echo
	echo "Uses the gpio utility written by Gordon Henderson. For more info visit:"
	echo "https://projects.drogon.net/raspberry-pi/wiringpi/the-gpio-utility/"
        echo
}

#Initialization functions
function parseArguments() {
	if [ "$#" -ge 1 ]; then
		specialVal=0
		for i in "$@"; do
			case $specialVal in
			0)	if [ $i == "--help" ]; then
                	                printHelp
        	                        exit 0
				elif [ $i == "--long" ]; then
					opt_DurationModifier="LONG"
				elif [ $i == "--short" ]; then
					opt_DurationModifier="SHORT"
	                        elif [ $i == "--verbose" ]; then
                        	        opt_verbose=true
                	        elif [ $i == "-a" ]; then
        	                        specialVal=1
	                        elif [ $i == "-t" ]; then
	                                specialVal=2
				else
                	                printHelp
        	                        exit 0
	                        fi
				;;
			1)	opt_animation=$(animationNameToAnimationIndex $i)
				specialVal=0
				;;
			2)	opt_duration=$i
				specialVal=0
				;;
			esac
		done
	fi
}

function initGPIOPins() {
	#Initialize all the GPIO ports to output mode
	for i in `seq 0 16`; do gpio mode $i out; done
}

#Utility functions
function genRndNum() {
	local v1=$((RANDOM % ($2 - $1) + $1 + 1))
	echo $v1
}

function animationNameToAnimationIndex() {
	case $1 in
	ON)	echo 0;;
	P01)	echo 1;;
	P02)	echo 2;;
	P03)	echo 3;;
	P04)	echo 4;;
	P05)	echo 5;;
	P06)	echo 6;;
	P07)	echo 7;;
	R01)	echo 8;;
	R02)	echo 9;;
	R03)	echo 10;;
	R04)	echo 11;;
	esac
}

function all_off() {
	for i in `seq 0 16`; do gpio write $i 0; done
}

#Animation functions
function animation_on() {
        for i in `seq 0 16`; do gpio write $i 1; done
	sleep 1
}

function animation_pattern_01() {
	for i in `seq 0 16`; do
                gpio write $i 1;
                sleep 0.15;
                gpio write $i 0;
        done
}

function animation_pattern_02() {
	for i in `seq 0 16`; do
                gpio write $i $((i % 2))
        done

        sleep 0.15;

        for i in `seq 0 16`; do
                gpio write $i $((($i + 1) % 2))
        done

        sleep 0.15
}

function animation_pattern_03() {
	for i in `seq 0 16`; do gpio write $i 1; done
        sleep 0.5
        for i in `seq 0 16`; do gpio write $i 0; done
        sleep 0.5
}

function animation_pattern_04() {
	for n in `seq 0 5`; do
                if [ $n -eq 0 ]; then
                        prevN=5;
                else
                        prevN=$((n - 1));
                fi

                if [ $prevN -lt 5 ]; then
                        gpio write $prevN 0;
                fi
		gpio write $((prevN + 5)) 0;
                gpio write $((prevN + 11)) 0;

                if [ $n -lt 5 ]; then
                        gpio write $n 1;
                fi
                gpio write $((n + 5)) 1;
                gpio write $((n + 11)) 1;

                sleep 0.25;
        done
}

function animation_pattern_05() {
	for i in `seq 0 16`; do
                gpio write $i 1;
                sleep 0.1;
        done

        for i in `seq 0 16`; do
                gpio write $i 0;
                sleep 0.1;
        done
}

function animation_pattern_06() {
	for i in `seq 0 4`; do gpio write $i 1; done
        sleep 0.5
        for i in `seq 0 4`; do gpio write $i 0; done
        for i in `seq 5 10`; do gpio write $i 1; done
        sleep 0.5
        for i in `seq 5 10`; do gpio write $i 0; done
        for i in `seq 11 16`; do gpio write $i 1; done
        sleep 0.5
        for i in `seq 11 16`; do gpio write $i 0; done
}

function animation_pattern_07() {
	for i in `seq 0 4`; do
                gpio write $i 1
                sleep 0.1
        done
        sleep 0.5
        for i in `seq 0 4`; do
                gpio write $((4-i)) 0
                sleep 0.1
        done
	for i in `seq 5 10`; do
                gpio write $i 1
                sleep 0.1
        done
        sleep 0.5
        for i in `seq 5 10`; do
                gpio write $((15-i)) 0
                sleep 0.1
        done
	for i in `seq 11 16`; do
                gpio write $i 1
                sleep 0.1
        done
        sleep 0.5
        for i in `seq 11 16`; do
                gpio write $((27-i)) 0
                sleep 0.1
        done
}

function animation_random_01() {
	for i in `seq 0 16`; do gpio write $i $((RANDOM & 1)); done
	sleep 0.05
}

function animation_random_02() {
	randomIndex=$((RANDOM % 17))
        gpio write $randomIndex 1
        sleep 0.5
        gpio write $randomIndex 0
}

function animation_random_03() {
	randomIndex1=$((RANDOM % 17))
        randomIndex2=$((RANDOM % 17))
        gpio write $randomIndex1 1
        gpio write $randomIndex2 1
        sleep 0.5
        gpio write $randomIndex1 0
        gpio write $randomIndex2 0
}

function animation_random_04() {
	randomIndex1=$((RANDOM % 5))
        randomIndex2=$((RANDOM % 6))
        randomIndex3=$((RANDOM % 6))
        gpio write $randomIndex1 1
        gpio write $((randomIndex2 + 5)) 1
        gpio write $((randomIndex3 + 11)) 1
        sleep 0.5
        gpio write $randomIndex1 0
        gpio write $((randomIndex2 + 5)) 0
        gpio write $((randomIndex3 + 11)) 0
}

#main functions
function generateNextAnimation() {
	if [ $opt_animation == -1 ]; then
		curAnimInd=$((RANDOM % ${#AnimationIDs[@]}))

		if [ $opt_duration == 0 ]; then
        		curDuration=$(genRndNum $MinDuration $MaxDuration)

			case $opt_DurationModifier in
			"LONG")		curDuration=$((curDuration * 2));;
			"NORMAL")	;;
			"SHORT")	curDuration=$((curDuration / 2));;
			*)		echo "Unknown duration modifier!"
			esac
        	fi
	else
		if [ $opt_duration == 0 ]; then
			curDuration=1000000000
		fi
	fi

	if [ $opt_verbose == true ]; then  echo "[`date +%T.%2N`] Animation ${AnimationIDs[$curAnimInd]}: ${AnimationNames[$curAnimInd]} ($curDuration)"; fi
}


#main starts here

#Options
opt_verbose=false
opt_animation=-1
opt_duration=0
opt_DurationModifier="NORMAL"

#Initializations
parseArguments "$@" #Parse the script's arguments
initGPIOPins #Initialize GPIO

declare -a -r AnimationIDs=( "ON" "P01" "P02" "P03" "P04" "P05" "P06" "P07" "R01" "R02" "R03" "R04" )
declare -a -r AnimationNames=(	"All ON"
				"Global sequential light-up left to right"
				"Blink alternate odd/even"
				"Blink all on/off"
				"Parallel left to right light-up one per group"
				"Global snake left to right"
				"Sequential group light-up top to bottom"
				"Grow and ungrow group by group"
				"Any number random on"
				"1 random on"
				"2 random on"
				"One per group random on" )
declare -a -r AnimationFunctions=( 	animation_on
					animation_pattern_01
					animation_pattern_02
					animation_pattern_03
					animation_pattern_04
					animation_pattern_05
					animation_pattern_06
					animation_pattern_07
					animation_random_01
					animation_random_02
					animation_random_03
					animation_random_04 )

declare -r MinDuration=5
declare -r MaxDuration=15

curDuration=$opt_duration
tElapsed=-1
startTime=0 
curAnimInd=$opt_animation

#Main loop
while ((($opt_duration == 0) || ($tElapsed < $curDuration))); do
	if [ $tElapsed -eq -1 ]; then
		all_off
		generateNextAnimation
		startTime=`date +%s`
	fi

	$(${AnimationFunctions[$curAnimInd]}) #Call the appropriate animation function

	tElapsed=$((`date +%s` - startTime))
 	if [ $opt_duration -eq 0 ] && [ $tElapsed -ge $curDuration ]; then tElapsed=-1; fi
done

#Finalizations
all_off
exit 0
